// import bcrypt from 'bcrypt';
// import 


//         // Hash the password before saving
// // export const hashpassword = async (password = String) => {
// //     const salt = await bcrypt.genSalt(10);
// //     const hashedPassword = await bcrypt.hashSync(password, salt);
// //     return hashedPassword;
// // }